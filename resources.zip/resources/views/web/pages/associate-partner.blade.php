@extends('web.layout.default')
@section('pageTitle', 'Associate Partner')

@section('content')
<p>Associate Partner</p>
@endsection